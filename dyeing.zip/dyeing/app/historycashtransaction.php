<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class historycashtransaction extends Model
{
    //
}
