<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cashtransaction extends Model
{
    //
}
