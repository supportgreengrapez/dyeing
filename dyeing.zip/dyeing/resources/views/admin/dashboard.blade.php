
    @extends('admin.layout.app')
    @section('content')
    <!-- page content -->
    <div class="right_col" role="main"> </div>
    <!-- /page content --> 
    
  @endsection