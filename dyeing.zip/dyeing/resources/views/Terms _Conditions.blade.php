@extends('layout.app')
@section('content')
<div class="container" style="margin-top: 20px;">
	<div class="phara1">
	<h2>TERMS & CONDITIONS</h2>
		
        	<p>Trial Period will be offered one time, for 7 days, after that you will have to subscribe to one of our packages in order to continue using our service</p>
            <p>If your subscription is canceled for some reason, you will still get access for the remaining days that you paid for, after that you can only view the data.
</p>  <p>All data on our website is not shared with any 3rd party, and is completely safe and secure</p>
            <p>Shipment Records of things that are prohibited in a specific region, will be monitored closely and their subscription will be canceled as soon as possible. Things such as cryptocurrency, alcohol, drugs of any sort (marijuana, cocaine, crystal meth etc.) </p>
        
		</div>
		
   </div>


@endsection