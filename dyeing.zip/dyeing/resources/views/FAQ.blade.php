@extends('layout.app')
@section('content')
<!--/ menu --> 
<div class="container" style="margin-top: 20px;">
	<div class="phara1">
	<h2><b></b>FAQ</b></h2>
		<h3>How can i start using BiltyBooks.com?</h3>
        <p>Just visit the website www.biltybooks.com, Click “Register” to create an account and then just login to visit your dashboard. There you can see everything that you need to manage your company’s Bilty Records. </p><br><br>
        <h3>What if i cancel my subscription, and there are still days remaining for my existing subscription?</h3>
        <p>     If you cancel your subscription and there are still days remaining for which you already paid, then you would be able to avail the remaining days and subscription will only be canceled once the remaining days are over. </p>
        <h3>How do i downgrade/upgrade my package with BiltyBooks.com?</h3>
        <p>Subscribe to the desired package by going to the subscriptions tab and selecting the package from there.</p>
        <h3>Do you offer customised reporting?</b></h3>
        <p>  Yes we do offer customised filters, which you can select from the filters shown above.</p>
        <h3>Can i download my Bilty Records from BiltyBooks.com?</h3>
        <p>    Yes you can download your Bilty Records from Biltybooks.com, in PDF, CSV etc. You can view these records in offline mode also, later on. </p>
        <h3>How many users can i manage with Bilty Books, at max?</h3>
        <p>You can avail 11 users maximum in our PRO package, for adding more users we can develop a custom solution for you, just contact us through our website.  </p>
        <h3>Do you offer multiple companies with a single username and password?</h3>
        <p>No, we are not offering multiple companies with a single username/password, but out team is working tirelessly to bring this feature live in the coming months.</p>
		</div>
   </div>
   
@endsection
