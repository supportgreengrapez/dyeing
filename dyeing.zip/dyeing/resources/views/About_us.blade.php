
@extends('layout.app')
@section('content')
<div class="container" style="margin-top: 20px;">
	<div class="phara1">
	<h2><b>About us</b></h2>
		<p>
		   BiltyBooks is a Bilty Record Keeping Cloud Software which aims to help its users maintain their outgoing and incoming shipments with different customers and suppliers. You can Add, manage, download and delete your bilty records instantly. All the data that you enter on the platform is 100% secure and you do not need to worry about any data theft or data sharing with any 3rd party. <br> <br>

Our goal is to provide our users with a seamless and smooth experience of entering their daily bilty records without the fear of any damage to their data in any way. <br><br>
		</p>
		</div>
   </div>

@endsection