@extends('layout.app')
@section('content')
<div class="container">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12">
			<div class="Faq">
				<h2>Service Promise</h2>
						<p>Memorable service is at the heart of Michael Kors. We are committed to make shopping a breeze,
						to offer the biggest selection of the absolute best products, and to give you style insight and
						insider access that works for your 24/7 lifestyle.</p>
						<h2>Service Promise</h2>
						<p>Memorable service is at the heart of Michael Kors. We are committed to make shopping a breeze,
						to offer the biggest selection of the absolute best products, and to give you style insight and
						insider access that works for your 24/7 lifestyle.</p>
						<h2>Service Promise</h2>
						<p>Memorable service is at the heart of Michael Kors. We are committed to make shopping a breeze,
						to offer the biggest selection of the absolute best products, and to give you style insight and
						insider access that works for your 24/7 lifestyle.</p>
						<h2>Service Promise</h2>
						<p>Memorable service is at the heart of Michael Kors. We are committed to make shopping a breeze,
						to offer the biggest selection of the absolute best products, and to give you style insight and
						insider access that works for your 24/7 lifestyle.</p>
						<h2>Service Promise</h2>
						<p>Memorable service is at the heart of Michael Kors. We are committed to make shopping a breeze,
						to offer the biggest selection of the absolute best products, and to give you style insight and
						insider access that works for your 24/7 lifestyle.</p>
						
						to offer the biggest selection of the absolute best products, and to give you style insight and
						insider access that works for your 24/7 lifestyle.</p>
			</div>
		</div>
	</div>
</div>
@endsection