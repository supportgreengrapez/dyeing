
<?php $__env->startSection('content'); ?> 
<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Dyeing Form</h3>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-6 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_content">
            <form method="post" action="<?php echo e(url('/')); ?>/add/dyeing/data" enctype="multipart/form-data">
              <?php if($errors->any()): ?>
              <div class="alert alert-danger"> <strong></strong> <?php echo e($errors->first()); ?> </div>
              <?php endif; ?>
              <?php echo e(csrf_field()); ?>

              <div class="form-group">
                <label>ISS</label>
                <input type="text" class="form-control" name="iss">
              </div>
              <div class="form-group">
                <label>Date</label>
                <input type="date" class="form-control" name="date">
              </div>
              <div class="form-group">
                <label>Weight</label>
                <input type="text" class="form-control" name="weight">
              </div>
              <div class="form-group">
                <label>Quality</label>
                <input type="text" class="form-control" name="quality">
              </div>
              <div class="form-group">
                <label>Quantity</label>
                <input type="text" class="form-control" name="quantity">
              </div>
              <div class="form-group">
                <label>Lot No</label>
                <input type="text" class="form-control" name="lot_no">
              </div>
              <div class="form-group">
                <label>Send To</label>
                <input type="text" class="form-control" name="send_to">
              </div>
              <div class="form-group">
                <button type="submit" class="btn btn-success">Submit</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/general.yoc.com.pk/dyeing/resources/views/admin/dyeing_form.blade.php ENDPATH**/ ?>