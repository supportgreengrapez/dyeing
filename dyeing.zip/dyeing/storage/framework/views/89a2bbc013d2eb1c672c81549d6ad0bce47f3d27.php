
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
      <form method="post" action="<?php echo e(url('/')); ?>/search/dyeing" enctype="multipart/form-data">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger"> <strong></strong> <?php echo e($errors->first()); ?> </div>
        <?php endif; ?>
        <?php echo e(csrf_field()); ?>

        <div class="row">
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group">
              <label>Start Date</label>
              <div class="input-group date datepicker" data-date-format="dd-mm-yyyy">
              <input class="form-control" type="text" name="s_date" autocomplete="off"/>
              <span class="input-group-addon"><i class="fa fa-calendar"></i></span> </div>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group">
              <label>End Date</label>
              <div class="input-group date datepicker" data-date-format="dd-mm-yyyy">
              <input class="form-control" type="text" name="e_date" autocomplete="off"/>
              <span class="input-group-addon"><i class="fa fa-calendar"></i></span> </div>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group">
              <label>Sender Name</label>
              <select class="js-example-basic-single form-control" name="s_name">
                <option value="" disable="true" selected="true" >---Select Sender---</option>
                
                    
          <?php if(count($result)>0): ?>
          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        
                
                <option value="<?php echo e($results->send_to); ?>"><?php echo e($results->send_to); ?></option>
                
                
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
              
              </select>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group">
              <label>Receiver Name</label>
              <select class="js-example-basic-single form-control" name="r_name">
                <option value="" disable="true" selected="true" >---Select Sender---</option>
                
                    
          <?php if(count($result)>0): ?>
          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        
                
                <option value="<?php echo e($results->recieved_from); ?>"><?php echo e($results->recieved_from); ?></option>
                
                
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
              
              </select>
            </div>
          </div>
          
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group">
                <button type="submit" class="btn btn-default btnn">Search</button>
            </div>
          </div>
        </div>
      </form>
      
      <div class="content_salogan">
        <h2>Issue Dyeing List</h2>
      </div>
      <a class="btn btn-default btnn" href="<?php echo e(url('/')); ?>/add/dyeing/form" style="margin-bottom:10px;">Issue Dyeing</a>
     
      <div class="table-responsive oder_form" id="order_form">
        <table id="example" class="table table-striped table-bordered display nowrap" cellspacing="0" width="100%"  style="color:black;">
          <thead>
            <tr>
              <th>LOT NO</th>
              <th>Tahn</th>
              <th>Date</th>
              <th>Weight</th>
              <th>Qauality</th>
              <th>Quantity</th>
              <th>Unit</th>
              <th>Send To</th>
              <th>Color</th>
              <th>System Lot No</th>
              <th>Action</th>
              <th>Challan No /GP No</th>
              <th>Folding</th>
              <th>Cut Piece</th>
              <th>Dyeing Lot</th>
              <th>Party Lot No</th>
              <th>Material</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
          
          <?php if(count($result)>0): ?>
          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($results->pk_id); ?></td>
            <td><?php echo e($results->tahn); ?></td>
            <td><?php echo e($results->date); ?></td>
            <td><?php echo e($results->weight); ?></td>
            <td><?php echo e($results->quality); ?></td>
            <td><?php echo e($results->quantity); ?></td>
            <td><?php echo e($results->unit); ?></td>
            <td><?php echo e($results->send_to); ?></td>
            <td><?php echo e($results->color); ?></td>
            <td><?php echo e($results->bl); ?></td>
            <td><a href="<?php echo e(url('/')); ?>/update/dyeing/<?php echo e($results->pk_id); ?>" class="">Received</a> | <a href="<?php echo e(url('/')); ?>/view/dyeing/detail/<?php echo e($results->pk_id); ?>" class="">View</a></td>
            
            <td><?php echo e($results->challan_no); ?></td>
            <td><?php echo e($results->folding); ?></td>
            <td><?php echo e($results->cut_piece); ?></td>
            <td><?php echo e($results->dyeing_lot); ?></td>
            <td><?php echo e($results->party_lot_no); ?></td>
            <td><?php echo e($results->material); ?></td>
            
            <td><?php if($results->status==0): ?> <span class="label label-warning">Open</span> <?php endif; ?>
                <?php if($results->status==1): ?> <span class="label label-success">Complete</span> <?php endif; ?>
                <?php if($results->status==2): ?> <span class="label label-primary">Return</span> <?php endif; ?>
                </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
            </tbody>
          
        </table>
      </div>
      
      
      
      
      
      <div class="content_salogan">
        <h2>Received for Dyeing List</h2>
      </div>
      <a class="btn btn-default btnn" href="<?php echo e(url('/')); ?>/received/dyeing/form" style="margin-bottom:10px;">Received for Dyeing</a>
      <div class="table-responsive oder_form" id="order_form">
        <table id="example3" class="table table-striped table-bordered display nowrap" cellspacing="0" width="100%"  style="color:black;">
          <thead>
            <tr>
              <th>LOT NO</th>
              <th>Tahn</th>
              <th>Date</th>
              <th>Weight</th>
              <th>Qauality</th>
              <th>Quantity</th>
              <th>Unit</th>
              <th>Received From</th>
              <th>Color</th>
              <th>System Lot No</th>
              <th>Action</th>
              <th>Challan No /GP No</th>
              <th>Folding</th>
              <th>Cut Piece</th>
              <th>Dyeing Lot</th>
              <th>Party Lot No</th>
              <th>Material</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
          
          <?php if(count($result2)>0): ?>
          <?php $__currentLoopData = $result2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($results->pk_id); ?></td>
            <td><?php echo e($results->tahn); ?></td>
            <td><?php echo e($results->date); ?></td>
            <td><?php echo e($results->weight); ?></td>
            <td><?php echo e($results->quality); ?></td>
            <td><?php echo e($results->quantity); ?></td>
            <td><?php echo e($results->unit); ?></td>
            <td><?php echo e($results->recieved_from); ?></td>
            <td><?php echo e($results->color); ?></td>
            <td><?php echo e($results->bl); ?></td>
            <td>
                <?php if($results->status == "0"): ?>
                <a href="<?php echo e(url('/')); ?>/move/to/dyeing/<?php echo e($results->pk_id); ?>" class="">Move to Dyeing</a>
                <?php else: ?>
                <p>already moved</p>
                <?php endif; ?>
            </td>
            
            <td><?php echo e($results->challan_no); ?></td>
            <td><?php echo e($results->folding); ?></td>
            <td><?php echo e($results->cut_piece); ?></td>
            <td><?php echo e($results->dyeing_lot); ?></td>
            <td><?php echo e($results->party_lot_no); ?></td>
            <td><?php echo e($results->material); ?></td>
            
            <td><?php if($results->status==0): ?> <span class="label label-warning">Open</span> <?php endif; ?>
                <?php if($results->status==1): ?> <span class="label label-success">Complete</span> <?php endif; ?>
                <?php if($results->status==2): ?> <span class="label label-primary">Return</span> <?php endif; ?>
                </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
            </tbody>
          
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/general.yoc.com.pk/dyeing/resources/views/client/dyeing_list.blade.php ENDPATH**/ ?>