<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/main.css">
<link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/util.css">
<!--/ menu --> 
<div class="limiter">
		<div class="container-login100" style="background-image:
url('<?php echo e(url('/')); ?>/img/home%20banner.png')">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
<?php if(session()->has('message')): ?>
<div class="alert alert-success">
    <?php echo e(session()->get('message')); ?>

</div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
<div class="alert alert-danger">
    <?php echo e(session()->get('error')); ?>

</div>
<?php endif; ?>
      <form method="post" action="<?php echo e(url('/')); ?>/login" class="login100-form validate-form">
          <?php echo e(csrf_field()); ?>

					<span class="login100-form-title p-b-49">
						Login
					</span>

					<div class="wrap-input100 validate-input m-b-23" data-validate = "Username is reauired">
						<span class="label-input100">User Email</span>
						<input class="input100" type="email" name="username" placeholder="Type your username">
						<span class="focus-input100" data-symbol="&#9993;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Password is required">
						<span class="label-input100">Password</span>
						<input class="input100" type="password" name="password" placeholder="Type your password">
						<span class="focus-input100" data-symbol="&#x26BF;"></span>
					</div>
					
					<div class="text-right p-t-8 p-b-31">
						<a href="<?php echo e(url('/')); ?>/reset/password">
							Forgot password?
						</a>
                        <a href="<?php echo e(url('/')); ?>/register">
							<strong>sign up</strong>
						</a>
					</div>
					
					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button type="submit"  class="login100-form-btn">
								Login
							</button>
                            
						</div>
                        
					</div>
					
				</form>
			</div>
		</div>
	</div> 
<!--footer-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/general.yoc.com.pk/dyeing/resources/views/login.blade.php ENDPATH**/ ?>