
<?php $__env->startSection('content'); ?> 
<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Dyeing List</h3>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_content">
              <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>ISS</th>
                    <th>Date</th>
                    <th>Weight</th>
                    <th>Qauality</th>
                    <th>Quantity</th>
                    <th>Lot No</th>
                    <th>Send To</th>
                  </tr>
                </thead>
                <tbody>
                
                <?php if(count($result)>0): ?>
                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($results->pk_id); ?></td>
                  <td><?php echo e($results->iss); ?></td>
                  <td><?php echo e($results->date); ?></td>
                  <td><?php echo e($results->weight); ?></td>
                  <td><?php echo e($results->quality); ?></td>
                  <td><?php echo e($results->quantity); ?></td>
                  <td><?php echo e($results->lot_no); ?></td>
                  <td><?php echo e($results->send_to); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                    </tbody>
              </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/general.yoc.com.pk/dyeing/resources/views/admin/dyeing_list.blade.php ENDPATH**/ ?>