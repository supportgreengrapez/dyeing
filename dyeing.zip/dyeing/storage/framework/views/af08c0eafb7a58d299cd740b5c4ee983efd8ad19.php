<?php $__env->startSection('content'); ?>
<!--/ menu -->
<div class="container">
<div class="row">
    <?php if($errors->any()): ?>
        <h4><?php echo e($errors->first()); ?></h4>
        <?php endif; ?>
        <?php if(session()->has('message')): ?>
<div class="alert alert-success">
<?php echo e(session()->get('message')); ?>

</div>
<?php endif; ?>
<div class="col-lg-12 col-md-12 col-sm-12">
	<div class="content_salogan">
    	<h2>Bilty Detail</h2>
    </div>
    <div class="oder_form" id="order_form" style="margin:0 auto; float:none; width:70%">
    <div class="right_col" role="main">
      <div class="">
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
              <div class="x_content" style="width:80%;">
                  <div class="img">
                    	<img src="<?php echo e(url('/')); ?>/img/Untitled-7.png" alt="img">
                    </div>
                <div class="member-left-side">
                  <div class="member-email clearfix"> <b>Bilty Number</b> <span><?php echo e($r->bilty_number); ?></span> </div>
                   <div class="member-email clearfix"> <div class="col-lg-6 nomarjin nopadding"><b>Quantity</b></div> <div class="col-lg-6  nomarjin nopadding"><span><?php echo e($r->quantity); ?></span> </div></div>
                 
                  <div class="member-email clearfix"> <b>Charge To</b> <span><?php echo e($r->charge_to); ?></span> </div>
                  <div class="member-email clearfix"> <b>To Record</b> <span><?php echo e($r->to_record); ?></span> </div>
                  <div class="member-email clearfix"> <b>Notes</b> <span><?php echo e($r->notes); ?></span> </div>
                  <div class="member-email clearfix"><div class="col-lg-6 nomarjin nopadding"><b>Description</b></div>
                  <div class="col-lg-6  nomarjin nopadding"><span><?php echo e($r->description); ?></span> </div></div>
                  <div class="member-email clearfix"> <b>Sender Company</b> <span><?php echo e($r->sender_company); ?></span> </div>
                  <div class="member-email clearfix"> <b>Receiver Company</b> <span><?php echo e($r->receiver_company); ?></span> </div>
                  <div class="member-email clearfix"> <b>Sender City</b> <span><?php echo e($r->sender_city); ?></span> </div>
                  <div class="member-email clearfix"> <b>Receiver City</b> <span><?php echo e($r->receiver_city); ?></span> </div>
               
                  <div class="member-email clearfix"> <b>Date Of Booking</b> <span><?php echo e($r->date_of_booking); ?></span> </div>
                  <div class="member-email clearfix"> <b>Date of Receiving</b> <span><?php echo e($r->date_of_receiving); ?></span> </div>
                  <div class="member-email clearfix"><b>Bilty Charges</b> <span><?php echo e($r->bilty_charges); ?></span> </div>
                  <div class="member-email clearfix"> <b>Bundle</b> <span><?php echo e($r->bundles); ?></span> </div>
                     <div class="member-email clearfix"> <div class="col-lg-6 nomarjin nopadding"><b>Goods Company</b></div><div class="col-lg-6 nomarjin nopadding"> <span><?php echo e($r->goods_company); ?></span> </div></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
    <!--<div class="oder_form" id="order_form">-->
    <!--<div class="right_col" role="main">-->
    <!--  <div class="">-->
    <!--    <div class="clearfix"></div>-->
    <!--    <div class="row">-->
    <!--      <div class="col-md-12 col-sm-12 col-xs-12">-->
    <!--        <div class="x_panel">-->
    <!--          <div class="x_content">-->
              		
    <!--            <div class="member-left-side">-->
               
    <!--            </div>-->
    <!--          </div>-->
    <!--        </div>-->
    <!--      </div>-->
    <!--    </div>-->
    <!--  </div>-->
    <!--</div>-->
    <!--</div>-->
    <!--<div class="oder_form" id="order_form">-->
    <!--<div class="right_col" role="main">-->
    <!--  <div class="">-->
    <!--    <div class="clearfix"></div>-->
    <!--    <div class="row">-->
    <!--      <div class="col-md-6 col-sm-6 col-xs-12">-->
    <!--        <div class="x_panel">-->
    <!--          <div class="x_content" style="width:100%;">-->
    <!--          		<div class="img">-->
    <!--                	<img src="<?php echo e(url('/')); ?>/img/Untitled-4.png" alt="img">-->
    <!--                </div>-->
    <!--            <div class="member-left-side">-->
                  
    <!--            </div>-->
    <!--          </div>-->
    <!--        </div>-->
    <!--      </div>-->
    <!--      <div class="col-md-6 col-sm-6 col-xs-12">-->
    <!--        <div class="x_panel">-->
    <!--          <div class="x_content" style="width:100%;">-->
    <!--          		<div class="img">-->
    <!--              <img src="<?php echo e(url('/')); ?>/img/Untitled-3.png" alt="img">-->
    <!--                </div>-->
    <!--            <div class="member-left-side">-->
                  
    <!--            </div>-->
    <!--          </div>-->
    <!--        </div>-->
    <!--      </div>-->
    <!--    </div>-->
    <!--  </div>-->
    <!--</div>-->
    <!--</div>-->
    <!--<div class="oder_form" id="order_form">-->
    <!--<div class="right_col" role="main">-->
    <!--  <div class="">-->
    <!--    <div class="clearfix"></div>-->
    <!--    <div class="row">-->
    <!--      <div class="col-md-6 col-sm-6 col-xs-12">-->
    <!--        <div class="x_panel">-->
    <!--          <div class="x_content">-->
    <!--            <div class="member-left-side">-->
                  
    <!--            </div>-->
    <!--          </div>-->
    <!--        </div>-->
    <!--      </div>-->
    <!--      <div class="col-md-6 col-sm-6 col-xs-12">-->
    <!--        <div class="x_panel">-->
    <!--          <div class="x_content">-->
    <!--            <div class="member-left-side">-->
                  
    <!--            </div>-->
    <!--          </div>-->
    <!--        </div>-->
    <!--      </div>-->
    <!--    </div>-->
    <!--  </div>-->
    <!--</div>-->
    
    <!--</div>-->
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/general.yoc.com.pk/dyeing/resources/views/client/records_view.blade.php ENDPATH**/ ?>