
<?php $__env->startSection('content'); ?> 
<!-- page content -->

<div class="container">
  <h2 style="color:#f9a848; text-align:center; margin-top:10px;"><strong>Folding Dyeing</strong></h2>
  <div class="clearfix"></div>
  <form method="post" action="<?php echo e(url('/')); ?>/floding/dyeing/data/<?php echo e($id); ?>" enctype="multipart/form-data">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger"> <strong></strong> <?php echo e($errors->first()); ?> </div>
    <?php endif; ?>
    <?php echo e(csrf_field()); ?>

    <?php if(count($result)>0): ?>
          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="row">
              <div class="col-md-6 col-sm-12 col-xs-12">
              <div class="form-group">
          <label>Lot No</label>
          <input type="text" class="form-control" name="lot_no" value="<?php echo e($results->lot_no); ?>" readonly>
          
        </div>
        </div>
          </div>
    <div class="row">
      <div class="col-md-6 col-sm-12 col-xs-12">
          
        
        <div class="form-group">
          <label>Send From</label>
          <input type="text" class="form-control" name="send_to" value="<?php echo e($results->send_to); ?>" readonly>
        </div>
        <div class="form-group">
          <label>Recieved From</label>
          <input type="text" class="form-control" name="recieved_from" value="<?php echo e($results->recieved_from); ?>" readonly>
        </div>
        <div class="form-group">
          <label>Quantity</label>
          <input type="text" class="form-control" name="quantity" value="<?php echo e($results->quantity); ?>">
        </div>
        <div class="form-group">
          <label>Unit</label>
          
          <select class="js-example-basic-single form-control" name="unit">
            <option   <?php if($results->unit=="feet"): ?> selected <?php endif; ?>  value="feet">feet</option>
            <option   <?php if($results->unit=="Meter"): ?> selected <?php endif; ?> value="Meter">Meter</option>
            <option   <?php if($results->unit=="Yard"): ?> selected <?php endif; ?> value="Yard">Yard</option>
            <option   <?php if($results->unit=="inchs"): ?> selected <?php endif; ?> value="inchs">Inches</option>
            <option   <?php if($results->unit=="Centimeter"): ?> selected <?php endif; ?> value="Centimeter">Centimeter</option>
            <option   <?php if($results->unit=="Kilogram"): ?> selected <?php endif; ?> value="Kilogram">Kilogram</option>
            <option   <?php if($results->unit=="Gram"): ?> selected <?php endif; ?> value="Gram
            ">Gram </option>
            <option   <?php if($results->unit=="Litre"): ?> selected <?php endif; ?> value="Litre">Litre</option>
            <option   <?php if($results->unit=="Mililitre"): ?> selected <?php endif; ?> value="Mililitre">Mililitre</option>
            <option   <?php if($results->unit=="Watt"): ?> selected <?php endif; ?> value="Watt">Watt</option>
            <option   <?php if($results->unit=="Volt-ampere"): ?> selected <?php endif; ?> value="Volt-ampere">Volt-ampere</option>
            <option   <?php if($results->unit=="Horse-power"): ?> selected <?php endif; ?> value="Horse-power">Horse-power</option>
            <option   <?php if($results->unit=="Cubic centimeter"): ?> selected <?php endif; ?> value="Cubic centimeter">Cubic centimeter</option>
            <option   <?php if($results->unit=="Radian"): ?> selected <?php endif; ?> value="Radian">Radian</option>
            <option   <?php if($results->unit=="Degree"): ?> selected <?php endif; ?> value="Degree">Degree</option>
            <option   <?php if($results->unit=="Bit"): ?> selected <?php endif; ?> value="Bit">Bit</option>
            <option   <?php if($results->unit=="Byte"): ?> selected <?php endif; ?> value="Byte">Byte</option>
            <option   <?php if($results->unit=="Kilobyte"): ?> selected <?php endif; ?> value="Kilobyte">Kilobyte</option>
            <option   <?php if($results->unit=="Megabyte"): ?> selected <?php endif; ?> value="Megabyte">Megabyte</option>
            <option   <?php if($results->unit=="GigaByte"): ?> selected <?php endif; ?> value="GigaByte">GigaByte </option>
            <option   <?php if($results->unit=="Terabyte"): ?> selected <?php endif; ?> value="Terabyte">Terabyte</option>
            <option   <?php if($results->unit=="Pixel"): ?> selected <?php endif; ?> value="Pixel">Pixel</option>
            <option   <?php if($results->unit=="Density per pixel"): ?> selected <?php endif; ?> value="Density per pixel
            ">Density per pixel </option>
            <option   <?php if($results->unit=="Pieces"): ?> selected <?php endif; ?> value="Pieces">Pieces </option>
            <option   <?php if($results->unit=="Packs"): ?> selected <?php endif; ?> value="packs">Packs</option>
            <option   <?php if($results->unit=="Pairs"): ?> selected <?php endif; ?> value="Pairs">Pairs</option>
            <option   <?php if($results->unit=="Dozen"): ?> selected <?php endif; ?> value="Dozen">Dozen</option>
            <option   <?php if($results->unit=="Vol"): ?> selected <?php endif; ?> value="Vol
            ">Vol </option>
            <option   <?php if($results->unit=="Percent"): ?> selected <?php endif; ?> value="Percent">Percent</option>
            <option   <?php if($results->unit=="Pond"): ?> selected <?php endif; ?> value="Pond">Pond</option>
          </select>
        </div>
        
        <div class="form-group">
          <button type="submit" class="txt2">Submit</button>
        </div>
      </div>
      <div class="col-md-6 col-sm-12 col-xs-12">
        <div class="form-group">
          <label>Color</label>
          <select class="js-example-basic-single form-control" name="color">
            <option value="White">White</option>
            <option value="Red">Red</option>
            <option value="Black">Black</option>
            <option value="Grey">Grey</option>
            <option value="Yellow">Yellow</option>
            <option value="Blue">Blue</option>
            <option value="Green">Green</option>
            <option value="Brown">Brown</option>
            <option value="Pink">Pink</option>
            <option value="Orange">Orange</option>
            <option value="Purple">Purple</option>
          </select>
        </div>
        <div class="form-group">
          <label>Challan No/GP No</label>
          <input type="text" class="form-control" name="challan_no" value="<?php echo e($results->challan_no); ?>">
        </div>
        <div class="form-group">
          <label>Folding</label>
          <input type="text" class="form-control" name="folding" value="<?php echo e($results->folding); ?>">
        </div>
        <div class="form-group">
          <label>Cut Piece</label>
          <input type="text" class="form-control" name="cut_piece" value="<?php echo e($results->cut_piece); ?>">
        </div>
        <div class="form-group">
          <label>Shortage</label>
          <input type="text" class="form-control" name="shortage" value="0">
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
  </form>
</div>
<!-- /page content --> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/general.yoc.com.pk/dyeing/resources/views/client/folding_dyeing.blade.php ENDPATH**/ ?>