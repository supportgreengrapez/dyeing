<?php $__env->startSection('content'); ?>
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Cash Transaction</h3>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
                <?php if($errors->any()): ?>
                <h4><?php echo e($errors->first()); ?></h4>
                <?php endif; ?>
                <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

        </div>
        <?php endif; ?>
        <?php if(session()->has('emessage')): ?>
    <div class="alert alert-danger">
    <?php echo e(session()->get('emessage')); ?>

    </div>
    <?php endif; ?>
    <form method="post" action="<?php echo e(url('/')); ?>/admin-get-transaction-date/complete">
      <?php echo e(csrf_field()); ?>

        <label for="">
        Start Date
      </label>
        <input  name="start_date" type="date">
        <label for="">
            End Date
          </label>
            <input name="end_date" type="date">
          <button class="btn btn-danger" type="submit">Search</button>
      </form>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
              <div class="x_content">
                  <div class="table-responsive">
                <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                  <thead>
            <tr>
                <th>ID</th>
                <th>Slip</th>
                <th>Username</th>
                <th>First Name</th>
                <th>Last Name</th>
                
                <th>Subscription</th>
                <th>No of Days</th>
                <th>Amount in USD</th>
                                <th>Amount in PKR</th>
                <th>Status</th>
                  <th>Created_at</th>
               
            </tr>
        </thead>
        <tbody>
          <?php if(count($c)>0): ?>
          <?php $__currentLoopData = $c; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($ct->cid); ?></td>
                <td>            <a href="#" data-toggle="modal" data-target="#myModal<?php echo e($ct->cid); ?>"><img src="<?php echo e(url('/')); ?>/storage/images/<?php echo e($ct->file); ?>" class="img-responsive" alt="" style="width:40%;"></a></td>
                <td><?php echo e($ct->username); ?></td>
                <td><?php echo e($ct->fname); ?></td>
                <td><?php echo e($ct->lname); ?></td>
                <td><?php echo e($ct->cs); ?></td>
                 <td><?php echo e($ct->days); ?></td>
                <td>$<?php echo e($ct->amount); ?></td>
             <td><?php echo e($ct->amount*121); ?></td>
                <th><span class="label label-success"><?php echo e($ct->status); ?></span></th>
                <td><?php echo e(Carbon\Carbon::parse($ct->d)->format('d-m-y')); ?></td>
            </tr>
            
            
         

<!-- Modal -->
<div id="myModal<?php echo e($ct->cid); ?>" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">PICTURE PREVIEW</h4>
      </div>
      <div class="modal-body">
      <img src="<?php echo e(url('/')); ?>/storage/images/<?php echo e($ct->file); ?>" class="img-responsive" alt="">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
                </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 

   <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/testing.biltybooks/resources/views/admin/cash_transactions.blade.php ENDPATH**/ ?>