<?php $__env->startSection('content'); ?>
<!--/ menu -->
<div class="container">
    
<div class="row">
        <?php if($errors->any()): ?>
        <h4><?php echo e($errors->first()); ?></h4>
        <?php endif; ?>
        <?php if(session()->has('message')): ?>
<div class="alert alert-success">
<?php echo e(session()->get('message')); ?>

</div>
<?php endif; ?>
<div class="col-lg-12 col-md-12 col-sm-12">
	<div class="content_salogan">
    	<h2>Users List</h2>
    </div>
    <?php if(session('subscription')!="NONE"): ?>
    <a class="btn btn-default btnn" href="<?php echo e(url('/')); ?>/create-users" style="margin-bottom:10px;">CREATE USER</a>
    <?php endif; ?>
     <div class="  filterable">
    <div class="panel-heading panalcolor">
                <h3 class="panel-title">Users</h3>
                <div class="pull-right">
                    <button class="btn btn-default btn-sm btn-filter"><span class="glyphicon glyphicon-filter"></span> Filter</button>
                </div>
            </div>
    <div class="table-responsive oder_form" id="order_form">
    
    <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%" style="color:black;">
        <thead>
            <tr class="filters">
                <th>Username</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>City <input type="text" class="form-control" placeholder="" disabled></th>
                <th>Access</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($su)>0): ?>
            <?php $__currentLoopData = $su; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($u->username); ?></td>
                <td><?php echo e($u->fname); ?></td>
                <td><?php echo e($u->lname); ?></td>
              <td><?php echo e($u->city); ?></td>
                <td><?php if($u->edit_permission ==1): ?><label class="label label-success">EDIT</label> <?php endif; ?> <?php if($u->delete_permission ==1): ?> <label class="label label-success">DELETE</label> <?php endif; ?> </td>
                <?php if(session('subscription')!="NONE"): ?>
                <td><span><a href="<?php echo e(url('/')); ?>/edit-user/<?php echo e($u->id); ?>">Edit</a></span> <span><a href="<?php echo e(url('/')); ?>/delete-user/<?php echo e($u->id); ?>">Delete</a></span></td>
        <?php endif; ?>    
        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
    </div>
    </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/testing.biltybooks/resources/views/client/manage_users.blade.php ENDPATH**/ ?>